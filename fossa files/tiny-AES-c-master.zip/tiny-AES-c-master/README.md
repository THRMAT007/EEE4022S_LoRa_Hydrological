### Tiny AES in C for Arduino

This fork allows users to use the original tiny-AES-c as a standard Arduino library. The only changes made were removing C and C++ test programs, Conan recipe scripts, CMake configuration and Makefile.
